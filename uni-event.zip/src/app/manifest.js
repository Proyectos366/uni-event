export default function manifest() {
  return {
    id: "/",
    name: "Rengifo Next",
    short_name: "Rengifo",
    description: "Aplicación web progresiva con Next.js y Prisma.",
    start_url: "/",
    display: "standalone",
    background_color: "#f4f2eb",
    theme_color: "#174a45",
    icons: [
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any maskable",
      },
    ],
  };
}